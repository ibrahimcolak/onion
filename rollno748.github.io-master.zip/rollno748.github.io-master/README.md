# Mohamed Ibrahim

## Introduction
E-resume to show it as website

Active Model: Model-3

## Installation Instructions

* Download the source code from the Github.
* Copy the content to Xampp or any http server directory
* You can directly invoke it in browser by opening the `index.html` file


## Tools Used

* Atom
* Markdown editor online (https://dillinger.io/)


Please rate a :star2: if you like it.
